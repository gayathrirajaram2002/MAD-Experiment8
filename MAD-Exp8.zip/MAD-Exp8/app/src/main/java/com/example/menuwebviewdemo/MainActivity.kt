package com.example.menuwebviewdemo

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var myWebView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myWebView = findViewById(R.id.webView)

        // Enable JavaScript
        myWebView.settings.javaScriptEnabled = true

        // Ensure links open inside the WebView instead of an external browser
        myWebView.webViewClient = WebViewClient()

        // Load default website
        myWebView.loadUrl("https://www.google.com")

        // Handle back button press for in-page navigation history
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (myWebView.canGoBack()) {
                    myWebView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    // 1. Inflate the options menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    // 2. Handle menu clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_google -> {
                myWebView.loadUrl("https://www.google.com")
                Toast.makeText(this, "Loading Google...", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.menu_wikipedia -> {
                myWebView.loadUrl("https://www.wikipedia.org")
                Toast.makeText(this, "Loading Wikipedia...", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.menu_github -> {
                myWebView.loadUrl("https://www.github.com")
                Toast.makeText(this, "Loading GitHub...", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.menu_refresh -> {
                myWebView.reload()
                Toast.makeText(this, "Refreshing...", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}